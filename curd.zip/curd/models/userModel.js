const mongoose=require('mongoose');

const userSchema=new mongoose.Schema({
    name:{
        type:'string',
        required:[true,'name is require'],
        trim:true,
        maxLength:[20,'name must be less then 20 charachter']
    },
    email:{
        type:'string',
        required:[true,'email is required'],
        unique:true
    }

})
module.exports=mongoose.model('user',userSchema)