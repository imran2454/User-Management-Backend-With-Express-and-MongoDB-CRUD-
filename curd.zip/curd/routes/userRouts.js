const express=require('express');
const {home,createUser,getUser,deleteUser,editUser}=require('../controlers/userControlers');
// const { deleteUser } = require('../controlers/userControlers');

const router=express.Router();
router.get('/',home)
router.post('/createuser',createUser)
router.get('/getuser', getUser)
router.delete('/deleteuser/:id',deleteUser)
router.put ('/edituser/:id',editUser)
module.exports=router;