require('dotenv').config();
const express=require('express');
const cors=require('cors');
const connectTodb=require('./config/db.js')

const app=express();
// Middleware
app.use(express.json())
app.use(express.urlencoded({extended:true}))
app.use(cors())
// init connection to db
connectTodb()

const userRouts=require('./routes/userRouts.js')
app.use('/',userRouts);

module.exports=app;